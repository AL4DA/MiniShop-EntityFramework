﻿using MiniShopentity1.Controller;

namespace MiniShopentity1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AuthController authController = new AuthController();
            MainController controller = new MainController();
            RegistrationController registrationController = new RegistrationController();
            int manage = 0;
            while (manage != 3)
            {
                Console.WriteLine("1.Registration\n2.Login\n3.Exit");
                manage = int.Parse(Console.ReadLine());
                if (manage == 1)
                {
                    registrationController.Registration();
                }
                if (manage == 2)
                {
                    controller.Menu();
                }
            }
        }
    }
}

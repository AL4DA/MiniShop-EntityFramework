﻿using MiniShopentity1.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiniShopentity1.Model;

namespace MiniShopentity1.Controller
{
    internal class RegistrationController
    {
        DataContext dataContext = new DataContext();
       public void Registration()
        {
            Console.Write("Enter Username: ");
            string username = Console.ReadLine();
            Console.Write("Enter Password: ");
            string password = Console.ReadLine();

            dataContext.users.Add(new Users()
            {
                Username = username,
                Password = password,
                Balance = 0
            });
            Console.WriteLine("Succses!");
            dataContext.SaveChanges();
        }
    }
}

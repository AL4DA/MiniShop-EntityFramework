﻿using MiniShopentity1.Data;
using MiniShopentity1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniShopentity1.Controller
{
    internal class AuthController
    {

        DataContext dataContext = new DataContext();
        public Users Auth()
        {
            Console.Write("Enter Username: ");
            string username = Console.ReadLine();
            Console.Write("Enter Password: ");
            string password = Console.ReadLine();

            var findedUser = dataContext.users.FirstOrDefault(u => u.Username == username && u.Password == password);

            if (findedUser != null)
            {
                Console.WriteLine("Succses Login!");
            }
            return findedUser;
        }
    }
}

﻿using MiniShopentity1.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiniShopentity1.Model;
using Microsoft.EntityFrameworkCore;

namespace MiniShopentity1.Controller
{
    internal class MainController
    {
        DataContext context = new DataContext();
        AuthController authController = new AuthController();

        public void Menu()
        {
            Users users = authController.Auth();
            if (users != null)
            {
                int manage = 0;
                while (manage != 4)
                {
                    Console.WriteLine("1.See Products\n2.Buy Products\n3.Inventory\n4.Exit");
                    manage = int.Parse(Console.ReadLine());

                    if (manage == 1)
                    {
                        SeeProducts();
                    }
                    if (manage == 2)
                    {
                        BuyProduct(users);
                    }
                    if (manage == 3)
                    {
                        Inventory(users);
                    }
                }
            }
        }

        private void SeeProducts()
        {
            context.Products.ToList().ForEach(p => Console.WriteLine(p));
        }

        public void BuyProduct(Users users)
        {
            Console.Write("Enter Product ID: ");
            int id = int.Parse(Console.ReadLine());

            var findedProduct = context.Products.FirstOrDefault(p => p.Id == id);

            if (findedProduct != null)
            {
                Console.Write("Enter Quantity: ");
                int quantity = int.Parse(Console.ReadLine());

                if (quantity > 0)
                {
                    var TotalPrice = quantity * findedProduct.Price;
                    Console.WriteLine($"Price: {TotalPrice}");

                    if (users.Balance >= TotalPrice)
                    {
                        Console.Write("Enter Amount: ");
                        decimal amount = decimal.Parse(Console.ReadLine());
                        if (amount >= TotalPrice)
                        {
                            Console.WriteLine("Purchased");
                            context.Entry(users).State = EntityState.Modified;
                            context.Entry(findedProduct).State = EntityState.Modified;
                            findedProduct.Quantity -= quantity;
                            users.Balance -= TotalPrice;
                            context.Orders.Add(new Orders()
                            {
                                ProductsId = findedProduct.Id,
                                UserId = users.Id,
                            });
                            context.SaveChanges();

                        }
                        else
                        {
                            Console.WriteLine("Error: Insufficient amount entered.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Insufficient balance.");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Quantity must be greater than zero.");
                }
            }
            else
            {
                Console.WriteLine("Product not found!");
            }
        }

        private void Inventory(Users users)
        {
            var inv = context.Orders.Where(u => u.UserId == users.Id).Include(or => or.User).Include(or => or.Products).ToList();

            foreach (var item in inv)
            {
                Console.WriteLine(item);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiniShopentity1.Model;

namespace MiniShopentity1.Data
{
    internal class DataContext : DbContext
    {
        public DbSet<Users> users { get; set; }
        public DbSet<Products> Products { get; set; }
        public DbSet<Orders> Orders { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=shopentitydb;Integrated Security=True;Trust Server Certificate=True");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniShopentity1.Model
{
    internal class Orders
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int ProductsId { get; set; }
        public Users User { get; set; }
        public Products Products { get; set; }

        public override string ToString()
        {
            return $"\nUser: {User.Username}\nProduct: {Products.ProductName}\nQuantity: {Products.Quantity}\nPrice: ${Products.Price}\n";
        }
    }
}
